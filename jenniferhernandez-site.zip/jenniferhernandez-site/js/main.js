/* ============================================
   Jennifer Hernandez REALTOR® — Main JavaScript
   jenniferhernandez.ai
   ============================================ */

// Mobile nav toggle
document.getElementById('jh-tog').addEventListener('click', function () {
  document.getElementById('jh-nl').classList.toggle('open');
});

// Smooth scroll for anchor links + close mobile nav
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      window.scrollTo({
        top: target.getBoundingClientRect().top + window.pageYOffset - 70,
        behavior: 'smooth'
      });
      document.getElementById('jh-nl').classList.remove('open');
    }
  });
});

// Nav shadow on scroll
window.addEventListener('scroll', () => {
  document.getElementById('jh-nav').style.boxShadow =
    window.scrollY > 50 ? '0 4px 28px rgba(0,0,0,.35)' : 'none';
});

// FAQ accordion
function faqT(btn) {
  const item = btn.closest('.faq-item');
  const isOpen = item.classList.contains('open');
  // Close all
  document.querySelectorAll('.faq-item.open').forEach(el => {
    el.classList.remove('open');
    el.querySelector('.faq-q').setAttribute('aria-expanded', 'false');
  });
  // Open clicked if it was closed
  if (!isOpen) {
    item.classList.add('open');
    btn.setAttribute('aria-expanded', 'true');
  }
}

// Netlify form success redirect (optional)
const form = document.querySelector('form[name="contact"]');
if (form) {
  form.addEventListener('submit', function () {
    // Netlify handles the submission natively
    // You can add a custom success message here if desired
  });
}

# Jennifer Hernandez — REALTOR® Website
### jenniferhernandez.ai | Powers Home Group | Century 21 NM

A fast, SEO-optimized real estate website for Jennifer Hernandez, serving Alexandria, VA and Northern Virginia. Built as a clean, standalone HTML/CSS/JS site — no WordPress, no plugins, no dependencies.

---

## 🚀 Deploy to Netlify in 3 Steps

### Option A — Drag & Drop (Easiest)
1. Go to [netlify.com](https://netlify.com) and log in
2. Drag this entire folder onto the Netlify dashboard
3. Done — your site is live!

### Option B — GitHub Import (Recommended)
1. Push this folder to a GitHub repository
2. In Netlify: **Add new site → Import from Git**
3. Connect your GitHub repo
4. Netlify auto-detects settings from `netlify.toml`
5. Click **Deploy** — live in ~30 seconds

### Option C — Netlify CLI
```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

---

## 📁 File Structure

```
jenniferhernandez-site/
├── index.html          ← Main website file
├── netlify.toml        ← Netlify config (headers, redirects)
├── .gitignore          ← Git ignore rules
├── README.md           ← This file
├── css/
│   └── style.css       ← All styles
├── js/
│   └── main.js         ← Nav, FAQ accordion, smooth scroll
└── images/
    ├── README.txt      ← Image instructions
    ├── jennifer-hero.jpg    ← ADD YOUR PHOTO HERE
    └── jennifer-about.jpg   ← ADD YOUR PHOTO HERE
```

---

## 📸 Before You Deploy — Add Your Photos

1. Open the `images/` folder
2. Add your headshot photos:
   - `jennifer-hero.jpg` — Main hero photo (portrait, ~800×1000px)
   - `jennifer-about.jpg` — About section photo (portrait, ~600×750px)
3. Compress them first at [squoosh.app](https://squoosh.app) for faster load times

---

## 📬 Contact Form Setup (Netlify Forms — FREE)

The contact form is pre-configured for **Netlify Forms** — it works automatically when deployed to Netlify. No backend needed, no monthly fee.

**To view form submissions:**
1. Go to your Netlify dashboard
2. Click your site → **Forms** tab
3. All submissions appear there automatically

**To get email notifications:**
- Netlify dashboard → **Forms** → **Form notifications**
- Add your email: jennifer@jenniferhernandez.ai

---

## 🔗 Custom Domain Setup

To point `jenniferhernandez.ai` to Netlify:

1. Netlify dashboard → **Domain settings** → **Add custom domain**
2. Enter: `jenniferhernandez.ai`
3. Update your DNS at GoDaddy:
   - Remove existing A records
   - Add Netlify's nameservers OR add a CNAME record pointing to your Netlify URL
4. SSL certificate is automatic (free via Let's Encrypt)

---

## ✏️ How to Update Content

Everything is in `index.html`. Search for these sections:

| What to update | Search for |
|----------------|------------|
| Phone number | `(202) 339-2511` |
| Email address | `jennifer@jenniferhernandez.ai` |
| Review count | `47 reviews` / `47 Google Reviews` |
| Stats bar numbers | `id="jh-stats"` |
| Services text | `id="jh-services"` |
| About bio | `id="jh-about"` |
| Review quotes | `id="jh-reviews"` |
| FAQ answers | `id="jh-faq"` |
| Footer copyright | `id="jh-footer"` |

---

## 🎨 Brand Colors

| Color | Hex | Used For |
|-------|-----|----------|
| Gold | `#BEAF87` | Accents, buttons, highlights |
| Gold Dark | `#A39060` | Hover states |
| Gold Light | `#D4C9A8` | Dark background accents |
| Gold Fill | `#F5F1E8` | Light background tints |
| Ink | `#111111` | Hero/dark sections |
| Dark | `#1A1A1A` | Body text |

---

## 📊 SEO Features Included

- ✅ Optimized `<title>` and `<meta description>`
- ✅ Open Graph tags for social sharing
- ✅ Schema.org JSON-LD (RealEstateAgent + FAQPage)
- ✅ Canonical URL
- ✅ Semantic HTML5 structure
- ✅ Mobile-responsive design
- ✅ Fast load time (no external JS frameworks)
- ✅ Security headers via netlify.toml
- ✅ Image lazy loading

---

## 📞 Support

**Jennifer Hernandez, REALTOR®**
Powers Home Group · Century 21 NM
📍 Alexandria, VA & Northern Virginia
📞 (202) 339-2511
✉️ jennifer@jenniferhernandez.ai
🌐 jenniferhernandez.ai

---

*Built with ❤️ for Northern Virginia's top military relocation REALTOR®*
